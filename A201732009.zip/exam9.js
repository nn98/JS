let a=[],b=[1,2,3];
a.push(b);
a.push(b);
a.push(b);
console.log(a);
a[0][0]=10;
console.log(a);