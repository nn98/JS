let s="one, two three four five ";
let r="";
for(let i of s){
    if(i!=" ")r+=i;
}
console.log(r);