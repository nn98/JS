for(let i=0;++i<10;){
    console.log(3+' * '+i+' = '+3*i);
}